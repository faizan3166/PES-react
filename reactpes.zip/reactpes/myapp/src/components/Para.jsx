import React from 'react'


const time=new Date().getHours()
let greet=""

let css={
    color:"",
    fontStyle:"italic", 
    backgroundColor:"black"
}


if((time>1&& time<12)){
    greet="Good Morning"
    css.color="green"
}
else if((time>=12 && time<19)){
    greet="Good AfterNoon"
    css.color="orange"
}
else{
    greet="Good Night"
    css.color="Black"
}

 const Para = () => {
  return (
    <div className='card'>
      
      <h2 >Hello Sir : <span style={css}>{greet}</span></h2>
      
    </div>
  )
}

export default Para
