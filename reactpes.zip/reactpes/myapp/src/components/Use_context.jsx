import React, { useContext } from 'react'
import { data,data1 } from '../App'



const Use_context = () => {
    let name=useContext(data)
    let age=useContext(data1)
  return (
    <div>
      <h1>My Name is : {name} age is : {age}</h1>
    </div>
  )
}

export default Use_context
