let Mdata=[
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"Wanted",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Salman Khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"Pathan",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Srk"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
    {
        imgs:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTuc3iITj4xv6yN24mfQVF4PLYVuiPUckhXEJwvt7OvUR0zWzAv",
        tittle:"PK",
        watch:"https://m.imdb.com/chart/top/",
        Aname:"Amir khan"
    },
]

export default Mdata