import React, { useMemo, useState } from 'react'

const Usememo = () => {
    let [add,setAdd]=useState(0)
    let [sub,setSub]=useState(100)

    let mul=useMemo(()=>{
        return add*10,console.log("click")
    },[add])
  return (
    <div>
      <h1>add :{add} mul {mul} </h1>
      <button onClick={()=>{setAdd(add+1)}}>add</button><br />
      <h1>Sub : {sub} </h1>
      <button onClick={()=>{setSub(sub-1)}}>Sub</button>
    </div>
  )
}

export default Usememo
