import React, { useContext, useEffect, useState } from 'react'
import { data,data1 } from '../App'



const Incdec = () => {
  let [Count,setCount]=useState(0)  

  let inc=()=>{
      setCount(Count+1)
  }
  
  let Dec=()=>{
    setCount(Count-1)
  }

    useEffect(()=>{
      alert("Hello")
    })
    let name=useContext(data)
    let age= useContext(data1)
  return (
    <div>
        <>
        <h1>My name is :{name}  age is :{age}</h1>
        <h1>Count : {Count}</h1>
        <button onClick={inc}>INC</button> &nbsp;
        <button onClick={Dec}>Dec</button>
        </>

   
    </div>
  )
}

export default Incdec
