import React from 'react'

const Head = () => {
  return (
    <div>
      <h1 contentEditable="true">Welcome to Skill Development To Learn with  </h1>
    </div>
  )
}

export default Head
