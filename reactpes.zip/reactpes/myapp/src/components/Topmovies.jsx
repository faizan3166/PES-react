import React from "react";

const Topmovies = () => {
  return (
    <div>
      <div>
        <h1 className="head">Top 5 Best Moives</h1>
      </div>
    </div>
  );
};

export default Topmovies;
