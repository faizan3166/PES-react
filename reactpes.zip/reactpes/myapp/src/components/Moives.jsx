import React from 'react'

const Moives = (props) => {
  return (
    <div>
      <div className="MainCard">
          <div className="Card">
            <div className="imgs">
              <img className='img' src={props.imgs} alt="" />
            </div>
            <div className="Cdata">
              <h4>{props.tittle}</h4>
              <a href={props.watch}>
                <button className=" btn">Watch</button>
              </a>
              <div className="actor">
                <h4>{props.Aname}</h4>
              </div>
            </div>
          </div>
        </div>
    </div>
  )
}

export default Moives
