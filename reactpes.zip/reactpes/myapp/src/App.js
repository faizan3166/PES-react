import React, { createContext, useContext } from "react";
import Head from './components/Head';
import Para from './components/Para';
import "./components/Date.css";
import Topmovies from "./components/Topmovies";
import Moives from "./components/Moives";
import Mdata from "./components/Mdata";
import Incdec from "./components/Incdec";
import Use_context from "./components/Use_context";
import Usememo from "./components/Usememo";
let card = (val) => {
  return (
    <Moives
      imgs={val.imgs}
      tittle={val.tittle}
      watch={val.watch}
      Aname={val.Aname}
    />
  );
};
let data = createContext();
let data1 = createContext();

function App() {
  let name = "faizan";
  let age = 20;

  return (
    <>
      <Usememo />
      <data.Provider value={name}>
        <data1.Provider value={age}>
          <Use_context />
          <Incdec />
        </data1.Provider>
      </data.Provider>
      <Topmovies />
      {Mdata.map(card)}
      <Head />
      <Para />
    </>
  );
}

export default App;
export { data, data1 };
